package com.app.Recipe;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class RecipeController {
	

}
